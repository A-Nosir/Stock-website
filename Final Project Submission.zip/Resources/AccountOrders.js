/*
 * Adds all interactive functionality of the user's orders page
 *
 * Might need to use setTimeout for stock price and order checks
 */

function initialize() {
    // Get and populate user's orders
    retrieveOrders();
}

// Retrieve user's orders from server
function retrieveOrders() {
    //Ajax request here
    let ordersTable = document.getElementById("orders");

    // Send a request to the server for all orders
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add orders to table
            let orders = JSON.parse(this.response);
            for (let i = 0; i < orders.length; i++) {
                let order = orders[i];
                let row = document.createElement("tr");
                row.setAttribute("name", "orderRow");
                row.setAttribute("id", order.orderId);
                row.innerHTML = `<td><a href=\"/Stocks/${order.symbol}\">${order.symbol}</a></td>
                <td>${order.stockName}</td><td>${order.type}</td><td>$${order.price}</td>
                <td>${order.initialNum}</td><td>${order.numUnfulfilled}</td>
                <td><button type=\"button\" onclick=\"cancel()\">Cancel</button></td>`;

                ordersTable.appendChild(row);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get orders!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Orders?count=0`, true);
    xhttp.send();
}

// Cancel order by sending a request to the server
function cancel() {

}
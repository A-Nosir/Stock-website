/*
 * Adds all interactive functionality of the user's portfolio page
 *
 * Might need to use setTimeout for stock price and order checks
 */

function initialize() {
    // Get and populate user's portfolio
    retrievePortfolio();
}

// Retrieve user's portfolio from server
function retrievePortfolio() {
    //Ajax request here
    let portfolioTable = document.getElementById("portfolio");

    // Send a request to the server for all the owned stocks
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add stocks to table
            let stocks = JSON.parse(this.response);
            for (let i = 0; i < stocks.length; i++) {
                let stock = stocks[i];
                let row = document.createElement("tr");
                row.setAttribute("name", "stockRow");
                row.innerHTML = `<td><a href=\"/Stocks/${stock.symbol}\">${stock.symbol}</a></td>
                <td>${stock.name}</td><td>${stock.sharesOwned}</td><td>$${stock.avgPaid}</td>
                <td>$${stock.currentPrice}</td><td>$${stock.totalValue}</td>`;

                portfolioTable.appendChild(row);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get investments!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Portfolio?count=0`, true);
    xhttp.send();
}
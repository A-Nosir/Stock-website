/*
 * Adds all interactive functionality of the user's events page
 *
 */

function initialize() {
    // Get and populate user's event Notifications and subscriptions
    retrieveNotifications();
    retrieveSubscriptions();

    document.getElementById("clear").addEventListener("click", clearAllNotifications);
}

/******************
 Notification Stuff 
 ******************/
// Retrieve user's notifications from server
function retrieveNotifications() {
    //Ajax request here
    let notificationsList = document.getElementById("Notifications");

    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add stocks to table
            let notifications = JSON.parse(this.response);
            let currTime = new Date();
            for (id in notifications) {
                let notification = notifications[id];
                let listItem = document.createElement("li");
                let notifTimeTxt = getNotifTriggerTxt(currTime, notification.time);
                let notifEventTxt = getNotifTxt(notification);
                // Give notification id that is a unique value assigned by the server when the notification is created
                listItem.setAttribute("id", notification.notifId);
                listItem.innerHTML = `<label>${notifTimeTxt}</label>
                <a href=\"/Stock/${notification.symbol}\"> ${notifEventTxt}</a>
                <button type=\"button\" onclick=\"clearNotification(this)\">Clear Notification</button>`;

                notificationsList.appendChild(listItem);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get listings!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Notifications`, true);
    xhttp.send();
}

// Return a text for how long ago a notification was triggered
function getNotifTriggerTxt(currTime, notifTime) {
    let timeDiff = (currTime - Number(notifTime)) / 1000;
    let displayText;
    // Check seconds
    if (timeDiff < 60) {
        displayText = Math.trunc(timeDiff) + " second";
        if (Math.trunc(timeDiff) != 1) { displayText += "s" }
        displayText += " ago: ";
        return displayText;
    }
    // Check mins
    timeDiff = timeDiff / 60;
    if (timeDiff < 60) {
        displayText = Math.trunc(timeDiff) + " minute";
        if (Math.trunc(timeDiff) != 1) { displayText += "s" }
        displayText += " ago: ";
        return displayText;
    }
    // Check hours
    timeDiff = timeDiff / 60;
    if (timeDiff < 24) {
        displayText = Math.trunc(timeDiff) + " hour";
        if (Math.trunc(timeDiff) != 1) { displayText += "s" }
        displayText += " ago: ";
        return displayText;
    }
    // Anything else return as days
    timeDiff = timeDiff / 24;
    displayText = Math.trunc(timeDiff) + " day";
    if (Math.trunc(timeDiff) != 1) { displayText += "s" }
    displayText += " ago: ";
    return displayText;
}

// Return a display text based on notification properties
function getNotifTxt(notif) {
    switch (notif.type) {
        case "price":
            let updown;
            if (notif.change > 0) {
                updown = "up " + notif.change;
            } else {
                updown = "down " + notif.change;
            }
            return notif.symbol + " is " + updown + "%";
        case "sell":
            return "Sold " + notif.numFulfilled + " " + notif.symbol + " shares at $" + notif.price;
        case "buy":
            return "Bought  " + notif.numFulfilled + " " + notif.symbol + " shares at $" + notif.price;
        default:
            // Shouldn't get here so pretend it's an ad I guess
            return "Your wealth awaits! Invest today!";
    }
}

// Clear the selected notification
function clearNotification(button) {
    // send remove to server
    button.parentNode.remove();
}

// Clear all notifications
function clearAllNotifications() {
    // send clear all to server
    document.getElementById("Notifications").innerHTML = "";
}

/******************
 Subscription Stuff 
 ******************/
// Retrieve user's event subscriptions from server
function retrieveSubscriptions() {
    //Ajax request here
    let subscriptionsList = document.getElementById("Subscriptions");

    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add stocks to table
            let subscriptions = JSON.parse(this.response);
            console.log(subscriptions);
            for (id in subscriptions) {
                let subscription = subscriptions[id];
                let listItem = document.createElement("li");
                // Give subscription id that is a unique value assigned by the server when the notification is created
                listItem.setAttribute("id", subscription.subId);
                listItem.innerHTML = `<a href=\"/Stock/${subscription.symbol}\">${subscription.symbol}</a>
                <label>${subscription.change}%</label><br>
                <button type=\"button\" onclick=\"edit(this)\">Edit Event</button>
                <button type=\"button\" onclick=\"remove(this)\">Remove Event</button>
                <button type=\"button\" onclick=\"activate(this)\">Deactivate</button>`;

                subscriptionsList.appendChild(listItem);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get listings!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Subscriptions`, true);
    xhttp.send();
}

// Prompt the user to assign the percentage change they want a notification for
function edit(button) {
    let percentChange = prompt("Enter the percentage change you want to subscribe to:");
    let percentLabelNode = button.previousSibling.previousSibling;

    // Check input validity
    if (isNaN(percentChange)) {
        alert("A number must be entered.");
    } else if (percentChange == 0) {
        alert("You can't subscribe to the status quo.");
    } else if (percentChange < 0) {
        //update server
        // sign already added
        percentLabelNode.innerText = percentChange + "%";
    } else {
        //update server
        percentLabelNode.innerText = "+" + percentChange + "%";
    }
}

function remove(button) {
    if (confirm("Are you sure you want to remove this event?")) {
        // Send to server 
        button.parentNode.remove();
    }
}

function activate(button) {
    if (button.innerText == "Activate") {
        // User wants to deactivate
        // Send to server 
        button.innerText = "Deactivate";
        alert("subscription deactivated");
    } else {
        // User wants to activate
        // Send to server 
        button.innerText = "Activate";
        alert("subscription activated");
    }
}
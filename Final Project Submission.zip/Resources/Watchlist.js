/*
 * Adds all interactive functionality for one of the user's watchlists
 * 
 *
 * Might need to use setTimeout for watchlist value
 */

var watchlistName;

function initialize(name) {
    var watchlistName = name;
    // Get user's watchlists
    retrieveWatchlist(name);
}

// Retrieve the user's watchlist data from server
function retrieveWatchlist(name) {
    //Ajax request here
    let stocksTable = document.getElementById("stocks");

    // Send a request to the server for all the owned stocks
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add stocks to table
            let stocks = JSON.parse(this.response);
            for (symbol in stocks) {
                let stock = stocks[symbol];
                let row = document.createElement("tr");
                row.setAttribute("name", "stockRow");
                row.innerHTML = `<td><a href=\"/Stocks/${stock.symbol}\">${stock.symbol}</a></td>
                <td>${stock.name}</td><td>${stock.sharesOwned}</td><td>$${stock.avgPaid}</td>
                <td>$${stock.currentPrice}</td><td>$${stock.totalValue}</td>`;

                stocksTable.appendChild(row);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get listings!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Watchlists/${name}`, true);
    xhttp.send();
}

function edit(button) {
    // parent is li with unique id, use that to open correct edit form
    watchlistForm(watchlistName);
}

/* 
 * Popup a form with text boxes for the watchlists data
 * retrieves a watchlist with watchlistName and populates the text boxes with the values and adds an edit button
 * if no watchlistName is given show an empty form and adds an add button to create a new watchlist
 * 
 * Need css first
 */
function watchlistForm(watchlistName) {
    if (watchlistName) {
        console.log("Edit " + watchlistName);
    } else {
        console.log("Add new watchlist");
    }
}
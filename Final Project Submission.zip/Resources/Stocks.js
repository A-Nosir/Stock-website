/*
 * Adds all interactive functionality to the general stocks page
 * 
 *
 * Might need to use setTimeout for stock price values
 */

function initialize() {
    // Get and populate stocks
    retrieveStocks();
}

// Retrieve user's portfolio from server
function retrieveStocks() {
    //Ajax request here
    let stocksTable = document.getElementById("stocks");

    // Send a request to the server for all the owned stocks
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add stocks to table
            let stocks = JSON.parse(this.response);
            for (symbol in stocks) {
                let stock = stocks[symbol];
                let row = document.createElement("tr");
                row.setAttribute("name", "stockRow");
                row.innerHTML = `<td><a href=\"/Stocks/${stock.symbol}\">${stock.symbol}</a></td>
                <td>${stock.name}</td><td>$${stock.currentPrice}</td><td>$${stock.dayHigh}</td>
                <td>$${stock.dayLow}</td>`;

                stocksTable.appendChild(row);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get listings!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/Stocks`, true);
    xhttp.send();
}
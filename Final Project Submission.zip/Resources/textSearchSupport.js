/*
 * Text search behaviour is shared by multiple pages, so place it here and request it when needed
 */

// The id of the rows to be searched and filtered
var rowName;

function initializeSearch(name) {
    rowName = name;

    // Set focus on text box and add enter button event to it
    document.getElementById("searchTerms").focus();
    document.getElementById("searchTerms").addEventListener("keyup", function(key) {
        // Number 13 is the "Enter" key on the keyboard
        if (key.keyCode === 13) {
            search();
        }
    });

    // Add button listeners
    document.getElementById("searchBtn").addEventListener("click", search);
    document.getElementById("clear").addEventListener("click", clear);
}

// Display results that match a symbol or a name
function search() {
    let searchText = document.getElementById("searchTerms").value;
    let rows = document.getElementsByName(rowName);

    rows.forEach(element => {
        let symbolNode = element.firstChild;
        // If the symbol node and its sibling (the Name node) include the search text, show the row
        // Turn all to lowercase to get a case insensitive search
        if (symbolNode.innerText.toLowerCase().includes(searchText.toLowerCase()) ||
            symbolNode.nextElementSibling.innerText.toLowerCase().includes(searchText.toLowerCase())) {
            element.hidden = false;
        } else {
            element.hidden = true;
        }
    });
}

function clear() {
    let orders = document.getElementsByName(rowName);
    document.getElementById("searchTerms").value = "";
    orders.forEach(element => { element.hidden = false; });
}
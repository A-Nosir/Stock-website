/*
 * Adds all interactive functionality of the user's history page
 *
 * Search is more sophisticated so it's implemented here
 */

function initialize() {
    // Get and populate user's orders
    retrieveHistory();

    document.getElementById("searchBtn").addEventListener("click", search);
    document.getElementById("clear").addEventListener("click", clear);
}

// Retrieve user's history from server
function retrieveHistory() {
    //Ajax request here
    let transactionsTable = document.getElementById("transactions");

    // Send a request to the server for the user's history
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add transactions to table
            let transactions = JSON.parse(this.response);
            for (let i = 0; i < transactions.length; i++) {
                let transaction = transactions[i];
                let transactionTxt = getDisplayTextFromType(transaction.type);
                let row = document.createElement("tr");
                row.setAttribute("name", "transactionRow");
                row.innerHTML = `<td>${transaction.date}</td>
                <td name=\"${transaction.type}\">${transactionTxt}</td>
                <td><a href=\"/Stocks/${transaction.symbol}\">${transaction.symbol}</a></td><td>${transaction.name}</td>
                <td>$${transaction.amount}</td><td>${transaction.shares}</td>`;

                transactionsTable.appendChild(row);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get investments!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/History`, true);
    xhttp.send();
}

function getDisplayTextFromType(type) {
    switch (type) {
        case "Deposit":
            return "Deposit";
        case "Withdraw":
            return "Withdrawal";
        case "Buy":
            return "Share purchase";
        case "Sell":
            return "Share sale";
        default:
            // Shouldn't get here so tell user to contact us
            return "Unrecognized transaction, contact representative pls.";
    }
}

function search() {
    let searchText = document.getElementById("searchTerms").value;
    let transaction = document.getElementById("transaction").value;
    let startDate = Date.parse(document.getElementById("startDate").value);
    let endDate = Date.parse(document.getElementById("endDate").value);

    let transactions = document.getElementsByName("transactionRow");

    // Check all search terms for each node
    transactions.forEach(element => {
        // First child is date, which has to be within selected range
        let dateNode = element.firstChild;

        // If a start date is selected, check it
        if (startDate) {
            console.log("check start date");
            if (Date.parse(dateNode.innerText) >= startDate) {
                element.hidden = false;
            } else {
                element.hidden = true;
                // element failed check, return
                return;
            }
        }
        // If an end date is selected, check it
        if (endDate) {
            console.log("check end date");
            if (Date.parse(dateNode.innerText) <= endDate) {
                element.hidden = false;
            } else {
                element.hidden = true;
                // element failed check, return
                return;
            }
        }

        // Next sibling is transaction type, which has a name we can check
        let typeNode = dateNode.nextElementSibling;
        // Only check if selected transaction is not Any
        if (transaction != "Any") {
            if (typeNode.getAttribute("name") == transaction) {
                element.hidden = false;
            } else {
                element.hidden = true;
                // element failed check, return
                return;
            }
        }

        // Next two siblings are symbol and name
        let symbolNode = typeNode.nextElementSibling;
        // Turn all to lowercase to get a case insensitive search
        if (symbolNode.innerText.toLowerCase().includes(searchText.toLowerCase()) ||
            symbolNode.nextElementSibling.innerText.toLowerCase().includes(searchText.toLowerCase())) {
            element.hidden = false;
        } else {
            element.hidden = true;
        }
    });

}

function clear() {
    let transactions = document.getElementsByName("transactionRow");

    document.getElementById("searchTerms").value = "";
    document.getElementById("transaction").value = "Any";
    document.getElementById("startDate").value = "";
    document.getElementById("endDate").value = "";

    transactions.forEach(element => { element.hidden = false; });
}
/*
 * Adds all interactive functionality of the user's overview page
 *
 * Might need to use setTimeout for stock price and order checks
 */

// Define Ids and other constants that could be used by multiple functions
const cashBalanceId = "cashBalance";
const potfolioBalanceId = "portfolioBalance";

function initialize() {
    // First retrieve and add portfolio and order information to the page
    retrievePortfolio();
    retrieveOrders();

    // Add listeners
    document.getElementById("deposit").addEventListener("click", deposit);
    document.getElementById("withdraw").addEventListener("click", withdraw);
    document.getElementById("seeMoreShares").addEventListener("click", toggleSharesVisibility);
    document.getElementById("seeMoreOrders").addEventListener("click", toggleOrdersVisibility);
    document.getElementById("seeAllShares").addEventListener("click", function() { location.href = "/User/ViewPortfolio"; });
    document.getElementById("seeAllOrders").addEventListener("click", function() { location.href = "/User/ViewOrders"; });
}

/* 
 * Retrieve the top entryCount number of stocks owned.
 * Note:
 *  - By default retrieves 5.
 *  - If 0 chosen, get all owned stocks
 */
function retrievePortfolio(entryCount = 5) {
    // Here would be an ajax request
    let portfolioTable = document.getElementById("portfolio");
    let dataRows = document.getElementsByName("stockRow");

    // Remove all entries
    while (dataRows.length > 0) {
        dataRows[0].remove();
    };

    // Send a request to the server with the number of desired stocks
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Update display above table
            if (entryCount == 0) {
                document.getElementById("shareVisibilityText").innerText = "all investments";
            } else {
                document.getElementById("shareVisibilityText").innerText = "top " + entryCount + " investments";
            }

            // Add stocks to table
            let stocks = JSON.parse(this.response);
            for (let i = 0; i < stocks.length; i++) {
                let stock = stocks[i];
                let row = document.createElement("tr");
                row.setAttribute("name", "stockRow");
                row.innerHTML = `<td><a href=\"/Stocks/${stock.symbol}\">${stock.symbol}</a></td>
                <td>${stock.name}</td><td>${stock.sharesOwned}</td><td>$${stock.avgPaid}</td>
                <td>$${stock.currentPrice}</td><td>$${stock.totalValue}</td>`;

                portfolioTable.appendChild(row);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get investments!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Portfolio?count=${entryCount}`, true);
    xhttp.send();
}

/* 
 * Retrieve the top entryCount number of buy/sell orders placed.
 * Note:
 *  - By default retrieves 5.
 *  - If 0 chosen, get all placed orders
 */
function retrieveOrders(entryCount = 5) {
    // Here would be an ajax request
    let ordersTable = document.getElementById("Orders");
    let dataRows = document.getElementsByName("orderRow");

    // Remove all entries
    while (dataRows.length > 0) {
        dataRows[0].remove();
    };

    // Send a request to the server with the number of desired orders
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Update display above table
            if (entryCount == 0) {
                document.getElementById("orderVisibilityText").innerText = "all orders";
            } else {
                document.getElementById("orderVisibilityText").innerText = "top " + entryCount + " orders";
            }

            // Add orders to table
            let orders = JSON.parse(this.response);
            for (let i = 0; i < orders.length; i++) {
                let order = orders[i];
                let row = document.createElement("tr");
                row.setAttribute("name", "orderRow");
                row.setAttribute("id", order.orderId);
                row.innerHTML = `<td><a href=\"/Stocks/${order.symbol}\">${order.symbol}</a></td>
                <td>${order.stockName}</td><td>${order.type}</td><td>$${order.price}</td>
                <td>${order.initialNum}</td><td>${order.numUnfulfilled}</td>
                <td><button type=\"button\" onclick=\"cancel()\">Cancel</button></td>`;

                ordersTable.appendChild(row);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get orders!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Orders?count=${entryCount}`, true);
    xhttp.send();
}

/* 
 * Deposit money into the user's account
 * Throw an error if trying to deposit:
 *   - a negative number 
 */
function deposit() {
    let amount = prompt("Please enter a deposit amount.", 0);
    let balance = document.getElementById(cashBalanceId);

    // Check input validity
    if (amount) {
        if (isNaN(amount)) {
            alert("A number must be entered.");
        } else if (amount < 0) {
            alert("You cannot deposit a negative amount.");
        } else {
            // update user balance in server
            let xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    balance.innerHTML = this.response;
                    alert("Balance was successfully updated!");
                } else if (this.readyState == 4 && this.status >= 400) {
                    alert("Balance was not updated!\n" +
                        "Code: " + this.status + "\n" +
                        "Message: " + this.response);
                }
            }
            xhttp.open("POST", `/User/Balance?amount=${amount}`, true);
            xhttp.send();
        }
    }
}

/* 
 * Withdraw money from the user's account
 * Throw an error if trying to withdraw:
 *   - a negative number 
 *   - more than the balance
 */
function withdraw() {
    let amount = prompt("Please enter a withdrawal amount.", 0);
    let balance = document.getElementById(cashBalanceId);

    // Check input validity
    if (amount) {
        if (isNaN(amount)) {
            alert("A number must be entered.");
        } else if (amount < 0) {
            alert("You cannot withdraw a negative amount.");
        } else if (amount > Number(balance.innerHTML)) {
            alert("You cannot withdraw more than your balance.");
        } else {
            // update user balance in server
            amount = -Number(amount);
            let xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    balance.innerHTML = this.response;
                    alert("Balance was successfully updated!");
                } else if (this.readyState == 4 && this.status >= 400) {
                    alert("Balance was not updated!\n" +
                        "Code: " + this.status + "\n" +
                        "Message: " + this.response);
                }
            }
            xhttp.open("POST", `/User/Balance?amount=${amount}`, true);
            xhttp.send();
        }
    }
}

/*
 * Toggles between seeing all shares in the table or just the top 5 by value
 * Order table by total value regardless of mode
 * Change button text accordingly
 */
function toggleSharesVisibility() {
    let toggleBtn = document.getElementById("seeMoreShares");
    if (toggleBtn.innerText === "See More") {
        // User wants to see more
        retrievePortfolio(10);
        toggleBtn.innerText = "See Less";
    } else {
        // User wants to see less
        retrievePortfolio();
        toggleBtn.innerText = "See More";
    }
}

/*
 * Toggles between seeing all orders in the table or just the top 5 by value
 * Order table by total value regardless of mode
 * Change button text accordingly
 */
function toggleOrdersVisibility() {
    let toggleBtn = document.getElementById("seeMoreOrders");
    if (toggleBtn.innerText === "See More") {
        // User wants to see more
        retrieveOrders(10);
        toggleBtn.innerText = "See Less";
    } else {
        // User wants to see less
        retrieveOrders();
        toggleBtn.innerText = "See More";
    }
}

// Send request to cancel an order
function cancel() {

}
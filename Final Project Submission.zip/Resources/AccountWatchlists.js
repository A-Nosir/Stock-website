/*
 * Adds all interactive functionality of the user's watchlists
 * 
 *
 * Might need to use setTimeout for watchlist value
 */

function initialize() {
    // Get user's watchlists
    retrieveWatchlists();
    document.getElementById("createWatchlist").addEventListener("click", createNewList);
}

// Retrieve user's watchlists from server
function retrieveWatchlists() {
    //Ajax request here
    let watchlistsList = document.getElementById("watchlists");

    // Send a request to the server for all the owned stocks
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            // Add stocks to table
            let watchlists = JSON.parse(this.response);
            for (symbol in watchlists) {
                let watchlist = watchlists[symbol];
                let listItem = document.createElement("li");
                //Base list id on list name and prevent user from creating watchlists with the same name
                listItem.setAttribute("id", watchlist.name);
                listItem.innerHTML = `<h4>${watchlist.name}</h4><table border=\"1\">
                <tr><th>Watchlist Value</th><th>No. of Stock Symbols</th></tr>
                <tr><td>$${watchlist.value}</td><td>${watchlist.symbols.length}</td></tr></table>
                <button type=\"button\" onclick=\"location.href='/User/ViewWatchlist/${watchlist.name}'\">Open Watchlist</button>
                <button type=\"button\" onclick=\"edit(this)\">Edit/Manage List</button>`;

                watchlistsList.appendChild(listItem);
            }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Failed to get listings!\n" +
                "Code: " + this.status + "\n" +
                "Message: " + this.response);
        }
    }
    xhttp.open("GET", `/User/Watchlists`, true);
    xhttp.send();
}

function edit(button) {
    // parent is li with unique id, use that to open correct edit form
    watchlistForm(button.parentNode.id);
}

// All it needs for now is to open an empty watchlistForm
function createNewList() {
    watchlistForm();
}

/* 
 * Popup a form with text boxes for the watchlists data
 * retrieves a watchlist with watchlistName and populates the text boxes with the values and adds an edit button
 * if no watchlistName is given show an empty form and adds an add button to create a new watchlist
 * 
 * Need css first
 */
function watchlistForm(watchlistName) {
    if (watchlistName) {
        console.log("Edit " + watchlistName);
    } else {
        console.log("Add new watchlist");
    }
}
/*
 * Adds all interactive functionality of a stock's portfolio page
 * Assumes that the symbol is in the body's id attribute
 *
 * Might need to use setTimeout for stock price and graph and order checks
 */

var SYMBOL;

function initialize(val) {
    // initialize history here
    SYMBOL = val;

    // all these depend on the user being logged in
    document.getElementById("addToWatchlist").addEventListener("click", addToWatchlist);
    document.getElementById("addEvent").addEventListener("click", addEvent);
    document.getElementById("buy").addEventListener("click", buy);
    document.getElementById("sell").addEventListener("click", sell);
    document.getElementById("search").addEventListener("click", search);
}

function addToWatchlist() {
    // retrieve all user watchlists and display in popup so they can pick from
    // or create a new one, this would display the watchlist creation form
    console.log("Add " + document.body.getAttribute("id") + " to your watchlist");
}

function addEvent() {
    // get user prompt then submit to server
    let percentChange = prompt("Enter the percentage change you want to subscribe to:");

    // Check input validity
    if (isNaN(percentChange)) {
        alert("A number must be entered.");
    } else if (percentChange == 0) {
        alert("You can't subscribe to the status quo.");
    } else {
        // send create request to server here
        console.log("Subscribe to a percentage change of: " + percentChange);
    }
}

function buy() {
    let shares = prompt("Please enter how many shares you want to buy?", 0);
    let price = prompt("Please enter how much you'd like to pay for the shares?", 0);

    // Server checks user balance and available stock before placing the order then update page here
    let ordersTable = document.getElementById("orders")

    // Check input validity
    if (shares && price) {
        if (isNaN(shares) || isNaN(price)) {
            alert("A number must be entered. Please try again.");
        } else if (shares < 0, price < 0) {
            alert("You cannot use negative values. Please try again.");
        } else {
            // update user balance in server
            let xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    let order = JSON.parse(this.response);
                    let row = document.createElement("tr");
                    // Order id assigned by server
                    row.setAttribute("id", order.orderId);
                    // Variables here and cancel button behaviour
                    row.innerHTML = `<tr><td>${order.type}</td><td>$${order.price}</td>
                    <td>${order.initialNum}</td><td>${order.numUnfulfilled}</td>
                    <td><button type=\"button\" onclick=\"cancelOrder(this)\">Cancel</button></td></tr>`;
                    ordersTable.appendChild(row);
                    alert("Buy order Successfully placed!");
                } else if (this.readyState == 4 && this.status >= 400) {
                    alert("Order was not placed!\n" +
                        "Code: " + this.status + "\n" +
                        "Message: " + this.response);
                }
            }
            xhttp.open("POST", `/Stocks/${SYMBOL}/Buy?shares=${shares}&price=${price}`, true);
            xhttp.send();
        }
    }
}

function sell() {
    let shares = prompt("Please enter how many shares you want to sell?", 0);
    let price = prompt("Please enter how much you'd like to sell the shares for?", 0);

    // Server checks user balance and available stock before placing the order then update page here
    let ordersTable = document.getElementById("orders")

    // Check input validity
    if (shares && price) {
        if (isNaN(shares) || isNaN(price)) {
            alert("A number must be entered. Please try again.");
        } else if (shares < 0, price < 0) {
            alert("You cannot use negative values. Please try again.");
        } else {
            // update user balance in server
            let xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    let order = JSON.parse(this.response);
                    let row = document.createElement("tr");
                    // Order id assigned by server
                    row.setAttribute("id", order.orderId);
                    // Variables here and cancel button behaviour
                    row.innerHTML = `<tr><td>${order.type}</td><td>$${order.price}</td>
                    <td>${order.initialNum}</td><td>${order.numUnfulfilled}</td>
                    <td><button type=\"button\" onclick=\"cancelOrder(this)\">Cancel</button></td></tr>`;
                    ordersTable.appendChild(row);
                    alert("Sell order Successfully placed!");
                } else if (this.readyState == 4 && this.status >= 400) {
                    alert("Order was not placed!\n" +
                        "Code: " + this.status + "\n" +
                        "Message: " + this.response);
                }
            }
            xhttp.open("POST", `/Stocks/${SYMBOL}/Sell?shares=${shares}&price=${price}`, true);
            xhttp.send();
        }
    }
}

function cancelOrder(button) {
    // send to serve using order id first
    button.parentNode.parentNode.remove();
}

function search() {
    let historyTable = document.getElementById("history");
    let startDate = Date.parse(document.getElementById("startDate").value);
    let endDate = Date.parse(document.getElementById("endDate").value);

    // send request to server with the date range to display
}